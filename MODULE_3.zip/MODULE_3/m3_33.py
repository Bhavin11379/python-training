"""
There are multiple ways to iterate over a dictionary in Python.

Access key using the build .keys() 
Access key without using a key() 
Iterate through all values using .values()
Iterate through all key, and value pairs using items()
Access both key and value without using items()
Print items in Key-Value in pair 
"""