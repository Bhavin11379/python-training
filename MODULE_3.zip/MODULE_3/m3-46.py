def my_range(x):
    if x in range(1,15):
        print(f"{x} is in our range.")
    else:
        print(f"{x} is not in our range.")

my_range(5)
my_range(20)