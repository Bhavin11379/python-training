l = [('one', 1), ('two', 2), ('three', 3)]
my_dict = dict(l)
print(my_dict)