"""
In Python, use the dict() function to convert a tuple to a dictionary. A dictionary object 
can be created with the dict() function. The dictionary is returned by the dict() method, 
which takes a tuple of tuples as an argument. A key-value pair is contained in each tuple.
"""