tup = (12,35,85,3,45)
print(tup)