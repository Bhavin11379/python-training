a=input("Enter The String : ")
r=a[::-1]

if (a==r):
    print("The string is palindrome")
else:
    print("The string is not palindrome")    