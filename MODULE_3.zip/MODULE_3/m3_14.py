import random
color_list = ['Red', 'Blue', 'Green', 'White', 'Black']
print(random.choice(color_list))