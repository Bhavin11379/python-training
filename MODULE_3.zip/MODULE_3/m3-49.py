"""
5 ways to perform pattern matching in Python:

Method-1: Using re.search() Function.
Method-2: Using re.match() Function.
Method-3: Using re.fullmatch() Function.
Method-4: Using re.findall() Function.
Method-5: Using re.finditer() Function.
"""