tup = ("tuple", False, 3.2, 1)
print(tup)
print(type(tup))