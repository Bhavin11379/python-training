def convert(s):
    str = ""

    for x in s:
        str += x
 
    return str

t=('d','e','v')
print(convert(t))