def check_list(l):
    if len(l)==0:
        print("List is empty")
    else:
        print("List is not empty")

l1=[1,2,3]
l2=[]
check_list(l1)
check_list(l2)