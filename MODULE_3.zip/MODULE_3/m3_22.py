l1=[1,2,'d','e','v',0]
t1=tuple(l1)
print(t1)
print(type(t1))