def convert(s):
    str = ""

    for x in s:
        str += x
 
    return str

l=['d','e','v']
print(convert(l))