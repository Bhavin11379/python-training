"""
append() adds a single element to the end of the list while . extend() can 
add multiple individual elements to the end of the list.
"""