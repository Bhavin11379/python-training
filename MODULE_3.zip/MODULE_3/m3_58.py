height = float(input("Height of trapezoid: "))
base_1 = float(input('Base 1 value: '))
base_2 = float(input('Base 2 value: '))
area = ((base_1 + base_2) / 2) * height
print("Area is:", area)