l1=[58,99,54,25,45,69,87,12,58,74,41,36,29,5,73]
l1.sort()
print("Second smallest number : ",l1[1])