t=("Python","C++")
l1=list(t)
l1[1]="Java"
t=tuple(l1)
print(t)