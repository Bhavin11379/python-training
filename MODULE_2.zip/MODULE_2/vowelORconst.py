letter = input("enter a character : ")

if (letter == "A" or letter == "a" or letter == "B" or letter == "b" or letter == "E" or letter == "e" or
letter == "I" or letter == "i" or letter == "O" or letter == "o" or letter == "u" or letter == "U") :
    print("your letter is vowel")
else:
    print("your letter is constant")