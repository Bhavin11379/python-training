from tokenize import String


string = input("enter string : ")
substring = input("enter substring from above string whose count you want to know : ")

count = string.count(substring)


print(count)