number = int(input("enter number : "))
if number % 2 == 0:
    print("your number is even")
else :
    print("your number is odd")
    