"""
It is a loop control statement that forces to execute the next 
iteration of tha loop while skipping the rest of the code inside 
the loop for the current iteration only.
"""