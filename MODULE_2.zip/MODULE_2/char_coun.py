string = input("enter string : ")
character = input("enter a character : ")

count = string.count(character)

print(count)