
# memory management
"""
memory allocatiion is an essential part of the memory management for a developer.
this processs basically a llots free space in the computer's virtual memory , and
there are two types of virtual memory works while executing programs.

> static memory allocatiion
> dynamic memory allocation-

"""