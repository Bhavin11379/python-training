a = int(input("Enter you number : "))
if a > 0:
    print("your number is positive.")
elif a == 0:
    print("your number is zero.")
else:
    print("your number is nagative.")