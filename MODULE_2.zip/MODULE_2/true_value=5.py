a = int(input("enter value : "))
b = int(input("enter value : "))

if a == b:
    print("true")
elif a + b == 5:
    print("true")
elif a - b == 5:
    print("true")
else:
    print("false")
    