list = []
for i in range(0,5):
    name = input("enter word : ")
    list.append(name)
a = max(len(list))
print(a)