string = input("enter string : ")
print(len(string))